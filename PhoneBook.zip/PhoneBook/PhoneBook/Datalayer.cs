﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace PhoneBook
{
    class Datalayer
    {
        SqlConnection con;
        SqlDataAdapter adapter;
        SqlCommand cmd;
        DataSet ds;

        public Datalayer()
        {
            con = new SqlConnection("server=localhost\\sqlexpress;user id=sa;password=password@1;database=Project_phonebook");
        }

        public bool Exists(string username)
        {
            string qry = "select user_name from users where user_name='"+username+"'";
            try
            {
                adapter = new SqlDataAdapter(qry, con);
                ds = new DataSet();
                DataTable dt;

                adapter.Fill(ds, "user");
                dt = ds.Tables["user"];

                if (dt.Rows.Count == 0)
                    return false;
                else
                    return true;
            }
            catch(Exception exp)
            {
                Console.WriteLine("Error: " + exp.Message);
                System.Environment.Exit(0);
                return true;
            }
            
         }

        public void Insert(string username, string password)// handle return void to int/string
        {
            if (!Exists(username))
            {
                string qry = "Insert into users values(@username,@password)";

                cmd = new SqlCommand(qry, con);
                cmd.Parameters.Add("@username", SqlDbType.NVarChar, 50);
                cmd.Parameters.Add("@password", SqlDbType.NVarChar, 50);

                cmd.Parameters[0].Value = username;
                cmd.Parameters[1].Value = password;

                try
                {
                    cmd.Connection.Open();
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
                catch(Exception exp)
                {
                    Console.WriteLine("Error: " + exp.Message);
                    con.Close();
                }
                Console.WriteLine("Record Added Successfully!!");
                createPhonebook(username);
            }
            else
            {
                Console.WriteLine("Username already exists!");
            }
        }

        public void createPhonebook(string username)
        {
            String qry = "create table pb_"+username+ @" ( id int IDENTITY(1,1) PRIMARY KEY, 
                                                          name varchar(50) NOT NULL, 
                                                          mobile varchar(15),
                                                          work varchar(15),
                                                          home varchar(15),
                                                          email_pers varchar(50),
                                                          email_work varchar(50),
                                                          addr_pers varchar(50),
                                                          addr_work varchar(50),
                                                          dob Date,
                                                          relation varchar(20),
                                                        )"; //relation Dropdown in UI

            cmd = new SqlCommand(qry, con);

            try
            {
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Exception exp)
            {
                Console.WriteLine("Error: " + exp.Message);
                con.Close();
                return;
            }
            Console.WriteLine("\nDirectory created Successfully!!");
        }
        public void deleteContact(string username, string contactname)
        {
            string qry = "delete from pb_" + username + " where name=@uname";
            cmd = new SqlCommand(qry, con);
            cmd.Parameters.Add("@uname", SqlDbType.NVarChar, 50);
            cmd.Parameters[0].Value = contactname;
            try
            {
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine("Error : "+e.Message);
                con.Close();
                return;
            }
            Console.WriteLine("Row Deleted Successfully!!");
        }

        public void updateContactnumber(string username, string contactname, string phone)
        {
            string qry = "update pb_"+username+" set mobile=@no where name=@c_name";
            cmd = new SqlCommand(qry, con);
            cmd.Parameters.Add("@no", SqlDbType.NVarChar, 15);
            cmd.Parameters.Add("@c_name", SqlDbType.NVarChar, 50);

            cmd.Parameters[0].Value = phone;
            cmd.Parameters[1].Value = contactname;
            try
            {
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine("Error : "+e.Message);
                con.Close();
                return;
            }
            Console.WriteLine("Row Updated Successfully!!");
        }

        public void updateContactname(string username, string contactname, string phone)
        {
            string qry = "update pb_" + username + " set name=@c_name where mobile=@no";
            cmd = new SqlCommand(qry, con);
            cmd.Parameters.Add("@no", SqlDbType.NVarChar, 15);
            cmd.Parameters.Add("@c_name", SqlDbType.NVarChar, 50);

            cmd.Parameters[0].Value = phone;
            cmd.Parameters[1].Value = contactname;
            try
            {
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.Message);
                con.Close();
                return;
            }
            Console.WriteLine("Row Updated Successfully!!");
        }
        public void Query(string username, string contactname)
        {
            string qry;
            qry = "select * from pb_"+username+ " where name='" + contactname + "'";
            adapter = new SqlDataAdapter(qry, con);
            ds = new DataSet();
            con.Open();
            adapter.Fill(ds, "contacts");
            //dtcontacts = ds.Tables["contacts"];
            Display();
            con.Close();
        }
        public void Display()
        {
           
            Console.WriteLine("Queried Contact ");
            Console.WriteLine("No  | Name  | Home | Mobile | Work | Email_personal | Email_official | Home_Addr | work_Addr | DOB | Reationship ");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------");
            DataTable dt;
            dt = ds.Tables["contacts"];
            for (int count = 0; count < dt.Rows.Count; count++)
            {
                Console.WriteLine(dt.Rows[count][0] + " | " + dt.Rows[count][1] + " | " + dt.Rows[count][2] + " | " + dt.Rows[count][3] + " | " + dt.Rows[count][4] + " | " + dt.Rows[count][5] + " | " + dt.Rows[count][6] + " | " + dt.Rows[count][7] + " | " + dt.Rows[count][8] + " | " + dt.Rows[count][9] + " | " + dt.Rows[count][10]);
            }

        }
        public void DisplayAll(string username)
        {
            string qry = "select * from pb_"+username;
            adapter = new SqlDataAdapter(qry, con);
            ds = new DataSet();
            adapter.Fill(ds, "contacts");
            Console.WriteLine("Record Count : " + ds.Tables["contacts"].Rows.Count.ToString());

            Console.WriteLine("Contact List of user "+username);
            Console.WriteLine("No  | Name  | Home | Mobile | Work | Email_personal | Email_official | Home_Addr | work_Addr | DOB | Relationship ");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------");
            DataTable dt;
            dt = ds.Tables["contacts"];
            for (int count = 0; count < dt.Rows.Count; count++)
            {
                Console.WriteLine(dt.Rows[count][0] + " | " + dt.Rows[count][1] + " | " + dt.Rows[count][2] + " | " + dt.Rows[count][3] + " | " + dt.Rows[count][4] + " | " + dt.Rows[count][5] + " | " + dt.Rows[count][6] + " | " + dt.Rows[count][7] + " | " + dt.Rows[count][8] + " | " + dt.Rows[count][9] + " | " + dt.Rows[count][10]);
            }

        }
        public void addContact(string username,string name,string home,string mobile,string work,string email_p,string email_w,string home_addr, string work_addr, DateTime dob,string relation)
        {
            string qry = "insert into pb_" + username + " values(@name,@home,@mobile,@work,@email_p,@email_w,@home_addr,@work_addr,@dob,@relation)";
            cmd = new SqlCommand(qry, con);
            cmd.Parameters.Add("@name", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@home", SqlDbType.NVarChar, 15);
            cmd.Parameters.Add("@mobile", SqlDbType.NVarChar, 15);
            cmd.Parameters.Add("@work", SqlDbType.NVarChar, 15);
            cmd.Parameters.Add("@email_p", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@email_w", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@home_addr", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@work_addr", SqlDbType.NVarChar, 50);
            cmd.Parameters.Add("@dob", SqlDbType.DateTime);
            cmd.Parameters.Add("@relation", SqlDbType.NVarChar, 50);

            cmd.Parameters[0].Value = name;
            cmd.Parameters[1].Value = home;
            cmd.Parameters[2].Value = mobile;
            cmd.Parameters[3].Value = work;
            cmd.Parameters[4].Value = email_p;
            cmd.Parameters[5].Value = email_w;
            cmd.Parameters[6].Value = home_addr;
            cmd.Parameters[7].Value = work_addr;
            cmd.Parameters[8].Value = dob;
            cmd.Parameters[9].Value = relation;

            try
            {
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.Message);
                con.Close();
                return;
            }
            Console.WriteLine("Row Inserted Successfully!!");

        }

    }
}
