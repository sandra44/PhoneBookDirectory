﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBook
{
    class DatalayerClient
    {
        static void Main(string[] args)
        {
            Datalayer dl = new Datalayer();
            //dl.Insert("user3", "456");
            //dl.deleteContactnumber("user3", "abc");
            //dl.updateContactname("user3", "sathya", "0000");
            //dl.Query("user3", "sathya");
            //dl.DisplayAll("user3");
            dl.addContact("user3", "Mom", "1234", "34435", "45655", "ad@g.com", "sdf@ydf.com", "bengaluru", "karnataka", new DateTime(1968, 04, 14), "mother");
        }
       
    }
}
